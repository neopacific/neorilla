$(document).ready(function () {
  alert('ededdsdsdsd')
  // $('#id_aassignees').hide();
  // $('#id_start_date').hide();


  // $("#id_period").on("change",function(){
  //   period_id = $(this).val()
  //   if (period_id === 'create_new_period'){
  //     $.ajax({
  //         type: "GET",
  //         url: 'create-period',
  //         success: function (response) {
  //           $("#PeriodModal").addClass("oh-modal--show");
  //           $("#periodModalTarget").html(response);
  //         },
  //       });
  //   }
  // });
});
