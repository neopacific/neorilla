import type { BuildConditionals } from '@stencil/core/internal';
export declare const BUILD: BuildConditionals;
export declare const Env: {};
export declare const NAMESPACE: string;
