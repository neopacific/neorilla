export { ScreenshotConnector } from './connector-base';
export { ScreenshotLocalConnector } from './connector-local';
export { Screenshot, ScreenshotBuild, ScreenshotCompareResults, ScreenshotDiff } from '@stencil/core/internal';
