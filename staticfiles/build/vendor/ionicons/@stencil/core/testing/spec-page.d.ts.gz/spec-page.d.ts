import type { NewSpecPageOptions, SpecPage } from '@stencil/core/internal';
export declare function newSpecPage(opts: NewSpecPageOptions): Promise<SpecPage>;
