const { createJestPuppeteerEnvironment } = require('./index.js');

module.exports = createJestPuppeteerEnvironment();
