import type * as d from '@stencil/core/internal';
export declare function resetBuildConditionals(b: d.BuildConditionals): void;
