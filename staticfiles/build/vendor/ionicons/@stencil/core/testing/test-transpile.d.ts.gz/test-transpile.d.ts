import type { TranspileOptions, TranspileResults } from '@stencil/core/internal';
export declare function transpile(input: string, opts?: TranspileOptions): TranspileResults;
