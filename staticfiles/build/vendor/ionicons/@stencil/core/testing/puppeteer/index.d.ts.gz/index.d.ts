export type { E2EElement, E2EPage } from './puppeteer-declarations';
export { newE2EPage } from './puppeteer-page';
