import type { E2EPage, NewE2EPageOptions } from './puppeteer-declarations';
export declare function newE2EPage(opts?: NewE2EPageOptions): Promise<E2EPage>;
