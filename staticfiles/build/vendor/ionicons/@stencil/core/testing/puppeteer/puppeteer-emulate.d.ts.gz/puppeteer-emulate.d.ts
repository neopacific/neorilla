import type { E2EProcessEnv, EmulateConfig } from '@stencil/core/internal';
export declare function setScreenshotEmulateData(userEmulateConfig: EmulateConfig, env: E2EProcessEnv): void;
