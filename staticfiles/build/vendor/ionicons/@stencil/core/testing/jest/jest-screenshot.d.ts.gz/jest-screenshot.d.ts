import type * as d from '@stencil/core/internal';
export declare function runJestScreenshot(config: d.ValidatedConfig, env: d.E2EProcessEnv): Promise<boolean>;
