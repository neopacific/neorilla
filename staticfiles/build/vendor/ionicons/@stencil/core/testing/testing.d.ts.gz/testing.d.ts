import type { Testing, ValidatedConfig } from '@stencil/core/internal';
export declare const createTesting: (config: ValidatedConfig) => Promise<Testing>;
