export declare const initBuildStatus: (data: {
    window: Window;
}) => void;
export declare const updateFavIcon: (linkElm: HTMLLinkElement, status: string) => void;
